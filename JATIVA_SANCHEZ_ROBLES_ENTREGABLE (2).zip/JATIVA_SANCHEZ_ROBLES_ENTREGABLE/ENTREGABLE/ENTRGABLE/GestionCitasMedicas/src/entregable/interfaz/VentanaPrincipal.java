package entregable.interfaz;

import entregable.negocio.Cita;
import entregable.negocio.Medico;
import entregable.negocio.Paciente;
import entregable.utilitario.SistemaCitas;

import javax.swing.*;
import java.awt.*;
import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.Comparator;
import java.util.List;

public class VentanaPrincipal extends JFrame {
    private SistemaCitas sistema;
    private DefaultListModel<String> modeloMedicos;
    private DefaultListModel<String> modeloPacientes;

    public VentanaPrincipal() {
        sistema = new SistemaCitas();
        modeloMedicos   = new DefaultListModel<>();
        modeloPacientes = new DefaultListModel<>();
        recargarListas();

        setTitle("Sistema Gestión Citas Médicas");
        setSize(800, 600);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JTabbedPane pestañas = new JTabbedPane();

// ----------- MÉDICO -----------
        JTabbedPane tabMedico = new JTabbedPane();
        tabMedico.addTab("Registrar", crearPanelRegistrarMedico());
        tabMedico.addTab("Mostrar citas médico", crearPanelMostrarCitasMedico());
        tabMedico.addTab("Disponibilidad", crearPanelConsultarDisponibilidad());
        tabMedico.addTab("Editar", crearPanelEditarMedico());
        pestañas.addTab("Médico", tabMedico);

// ----------- PACIENTE -----------
        JTabbedPane tabPaciente = new JTabbedPane();
        tabPaciente.addTab("Registrar", crearPanelRegistrarPaciente());
        tabPaciente.addTab("Editar", crearPanelEditarPaciente());
        tabPaciente.addTab("Mostrar / Historial / Citas", crearPanelMostrarCitasPaciente());
        tabPaciente.addTab("Cancelar Cita", crearPanelCancelarCitaPaciente());
        pestañas.addTab("Paciente", tabPaciente);



// ----------- CITAS -----------
        pestañas.addTab("Asignar Citas", crearPanelAsignarCita());

// ----------- EN CONSULTA -----------
        pestañas.addTab("En Consulta", crearPanelEnConsulta());

        add(pestañas);
    }

    //aqui metodos

    //Método en consulta

    private JPanel crearPanelEnConsulta() {
        JPanel panel = new JPanel(new BorderLayout());
        JPanel top = new JPanel(new GridLayout(4, 2, 10, 10));

        JLabel lCitas = new JLabel("Citas activas en esta hora:");
        JComboBox<Cita> comboCitas = new JComboBox<>();

        JLabel lNotas = new JLabel("Nota para agregar al historial:");
        JTextField fNotas = new JTextField();

        JButton bAgregarNota = new JButton("Agregar al Historial");
        JButton bActualizar = new JButton("Actualizar citas activas");

        JTextArea areaHistorial = new JTextArea();
        areaHistorial.setEditable(false);
        JScrollPane scroll = new JScrollPane(areaHistorial);

        top.add(lCitas);
        top.add(comboCitas);
        top.add(lNotas);
        top.add(fNotas);
        top.add(new JLabel()); // espacio vacío
        top.add(bAgregarNota);
        top.add(new JLabel()); // espacio vacío
        top.add(bActualizar);

        panel.add(top, BorderLayout.NORTH);
        panel.add(scroll, BorderLayout.CENTER);

        // Método para actualizar las citas activas en esta hora
        Runnable cargarCitas = () -> {
            comboCitas.removeAllItems();
            LocalDate hoy = LocalDate.now();
            LocalTime ahora = LocalTime.now().withSecond(0).withNano(0);

            for (Paciente p : sistema.obtenerTodosPacientes()) {
                for (Cita c : p.getHistoriaClinica().getCitas()) {
                    if (!c.isCancelada() && c.getFecha().equals(hoy)) {
                        LocalTime horaCita = c.getHora();
                        LocalTime finCita = horaCita.plusHours(1);
                        if (!ahora.isBefore(horaCita) && ahora.isBefore(finCita)) {
                            comboCitas.addItem(c);
                        }
                    }
                }
            }
        };

        // Cargar citas al iniciar
        cargarCitas.run();

        bActualizar.addActionListener(e -> cargarCitas.run());

        bAgregarNota.addActionListener(e -> {
            try {
                Cita citaSeleccionada = (Cita) comboCitas.getSelectedItem();
                if (citaSeleccionada == null)
                    throw new IllegalArgumentException("No hay una cita activa seleccionada.");

                String nota = fNotas.getText().trim();
                if (nota.isEmpty()) throw new IllegalArgumentException("La nota no puede estar vacía.");

                Paciente p = citaSeleccionada.getPaciente();
                p.agregarEntradaHistoria(nota);
                areaHistorial.setText(p.getHistoriaMedica());
                fNotas.setText("");

                JOptionPane.showMessageDialog(this,
                        "Nota agregada al historial médico del paciente.",
                        "Éxito", JOptionPane.INFORMATION_MESSAGE);
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this,
                        ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        return panel;
    }

    //panel editar medico

    private JPanel crearPanelEditarMedico() {
        JPanel panel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.anchor = GridBagConstraints.WEST;

        JLabel lId = new JLabel("ID Médico:");
        JTextField fId = new JTextField(10);
        JButton bBuscar = new JButton("Buscar");

        JLabel lTel = new JLabel("Teléfono:");
        JTextField fTel = new JTextField(15);

        JLabel lDir = new JLabel("Dirección:");
        JTextField fDir = new JTextField(20);

        JLabel lEsp = new JLabel("Especialidad:");
        String[] especialidades = {"Medicina General", "Pediatría", "Cardiología", "Ginecología", "Dermatología"};
        JComboBox<String> cbEsp = new JComboBox<>(especialidades);

        JLabel lHi = new JLabel("Horario Inicio (HH:mm):");
        JTextField fHi = new JTextField(10);

        JLabel lHf = new JLabel("Horario Fin (HH:mm):");
        JTextField fHf = new JTextField(10);

        JCheckBox chkAusente = new JCheckBox("Marcar como AUSENTE");
        JCheckBox chkActivo = new JCheckBox("Marcar como ACTIVO");

        chkAusente.addActionListener(e -> {
            if (chkAusente.isSelected()) chkActivo.setSelected(false);
        });
        chkActivo.addActionListener(e -> {
            if (chkActivo.isSelected()) chkAusente.setSelected(false);
        });

        // ✅ Lista de médicos
        DefaultListModel<String> modeloMedicos = new DefaultListModel<>();
        JList<String> listaMedicos = new JList<>(modeloMedicos);
        listaMedicos.setVisibleRowCount(4);
        JScrollPane scrollMedicos = new JScrollPane(listaMedicos);

        for (Medico m : sistema.obtenerTodosMedicos()) {
            modeloMedicos.addElement(m.getId() + ": " + m.getNombre());
        }

        listaMedicos.addListSelectionListener(e -> {
            String seleccion = listaMedicos.getSelectedValue();
            if (seleccion != null && seleccion.contains(":")) {
                String idSeleccionado = seleccion.split(":")[0].trim();
                fId.setText(idSeleccionado);
            }
        });

        JButton bEditar = new JButton("Guardar Cambios");

        int y = 0;
        gbc.gridx = 0; gbc.gridy = y; panel.add(lId, gbc); gbc.gridx = 1; panel.add(fId, gbc); gbc.gridx = 2; panel.add(bBuscar, gbc);
        gbc.gridx = 0; gbc.gridy = ++y; panel.add(lTel, gbc); gbc.gridx = 1; panel.add(fTel, gbc);
        gbc.gridx = 0; gbc.gridy = ++y; panel.add(lDir, gbc); gbc.gridx = 1; panel.add(fDir, gbc);
        gbc.gridx = 0; gbc.gridy = ++y; panel.add(lEsp, gbc); gbc.gridx = 1; panel.add(cbEsp, gbc);
        gbc.gridx = 0; gbc.gridy = ++y; panel.add(lHi, gbc); gbc.gridx = 1; panel.add(fHi, gbc);
        gbc.gridx = 0; gbc.gridy = ++y; panel.add(lHf, gbc); gbc.gridx = 1; panel.add(fHf, gbc);
        gbc.gridx = 0; gbc.gridy = ++y; panel.add(chkAusente, gbc); gbc.gridx = 1; panel.add(chkActivo, gbc);
        gbc.gridx = 1; gbc.gridy = ++y; gbc.anchor = GridBagConstraints.CENTER; panel.add(bEditar, gbc);

        //  Lista scrollable al final
        gbc.gridx = 0; gbc.gridy = ++y; gbc.gridwidth = 3;
        panel.add(scrollMedicos, gbc);

        //  Buscar médico
        bBuscar.addActionListener(e -> {
            try {
                int id = Integer.parseInt(fId.getText().trim());
                Medico m = sistema.obtenerMedico(id);
                if (m == null) throw new IllegalArgumentException("Médico no encontrado");

                fTel.setText(m.getTelefono());
                fDir.setText(m.getDireccion());
                cbEsp.setSelectedItem(m.getEspecialidad());
                fHi.setText(m.getHorarioInicio().toString());
                fHf.setText(m.getHorarioFin().toString());
                chkAusente.setSelected(m.isAusente());
                chkActivo.setSelected(!m.isAusente());
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        // Guardar cambios
        bEditar.addActionListener(e -> {
            try {
                int id = Integer.parseInt(fId.getText().trim());
                Medico m = sistema.obtenerMedico(id);
                if (m == null) throw new IllegalArgumentException("Médico no encontrado");

                String tel = fTel.getText().trim();
                String dir = fDir.getText().trim();
                String esp = (String) cbEsp.getSelectedItem();

                if (fHi.getText().trim().isEmpty() || fHf.getText().trim().isEmpty()) {
                    throw new IllegalArgumentException("No se puede dejar el horario en blanco.");
                }

                LocalTime hi = LocalTime.parse(fHi.getText().trim());
                LocalTime hf = LocalTime.parse(fHf.getText().trim());

                if (hf.isBefore(hi))
                    throw new IllegalArgumentException("El horario de fin no puede ser antes del inicio");

                boolean ausente = chkAusente.isSelected();

                sistema.actualizarDatosMedico(id,
                        tel.isEmpty() ? m.getTelefono() : tel,
                        dir.isEmpty() ? m.getDireccion() : dir,
                        esp,
                        hi,
                        hf,
                        ausente
                );

                JOptionPane.showMessageDialog(this, "Médico actualizado correctamente");
                fId.setText(""); fTel.setText(""); fDir.setText(""); fHi.setText(""); fHf.setText("");
                chkAusente.setSelected(false); chkActivo.setSelected(false);
                recargarListas();

            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        return panel;
    }

    // metodo EditarPaciente

    private JPanel crearPanelEditarPaciente() {
        JPanel panel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.anchor = GridBagConstraints.WEST;

        JLabel lId = new JLabel("ID Paciente:");
        JTextField fId = new JTextField(10);
        JButton bBuscar = new JButton("Buscar");

        JLabel lTel = new JLabel("Teléfono:");
        JTextField fTel = new JTextField(15);

        JLabel lDir = new JLabel("Dirección:");
        JTextField fDir = new JTextField(20);

        JButton bEditar = new JButton("Guardar Cambios");

        //  Lista de pacientes
        DefaultListModel<String> modeloPacientes = new DefaultListModel<>();
        JList<String> listaPacientes = new JList<>(modeloPacientes);
        listaPacientes.setVisibleRowCount(4);
        JScrollPane scrollPacientes = new JScrollPane(listaPacientes);

        for (Paciente p : sistema.obtenerTodosPacientes()) {
            modeloPacientes.addElement(p.getId() + ": " + p.getNombre());
        }

        listaPacientes.addListSelectionListener(e -> {
            String seleccion = listaPacientes.getSelectedValue();
            if (seleccion != null && seleccion.contains(":")) {
                String idSeleccionado = seleccion.split(":")[0].trim();
                fId.setText(idSeleccionado);
            }
        });

        int y = 0;
        gbc.gridx = 0; gbc.gridy = y; panel.add(lId, gbc); gbc.gridx = 1; panel.add(fId, gbc); gbc.gridx = 2; panel.add(bBuscar, gbc);
        gbc.gridx = 0; gbc.gridy = ++y; panel.add(lTel, gbc); gbc.gridx = 1; panel.add(fTel, gbc);
        gbc.gridx = 0; gbc.gridy = ++y; panel.add(lDir, gbc); gbc.gridx = 1; panel.add(fDir, gbc);
        gbc.gridx = 1; gbc.gridy = ++y; gbc.anchor = GridBagConstraints.CENTER; panel.add(bEditar, gbc);

        // Agregar lista al panel
        gbc.gridx = 0; gbc.gridy = ++y; gbc.gridwidth = 3;
        panel.add(scrollPacientes, gbc);

        // Acción Buscar
        bBuscar.addActionListener(e -> {
            try {
                int id = Integer.parseInt(fId.getText().trim());
                Paciente p = sistema.obtenerPaciente(id);
                if (p == null) throw new IllegalArgumentException("Paciente no encontrado");

                fTel.setText(p.getTelefono());
                fDir.setText(p.getDireccion());

            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        // Acción Editar
        bEditar.addActionListener(e -> {
            try {
                int id = Integer.parseInt(fId.getText().trim());
                Paciente p = sistema.obtenerPaciente(id);
                if (p == null) throw new IllegalArgumentException("Paciente no encontrado");

                String tel = fTel.getText().trim();
                String dir = fDir.getText().trim();

                sistema.editarPaciente(id,
                        tel.isEmpty() ? p.getTelefono() : tel,
                        dir.isEmpty() ? p.getDireccion() : dir
                );

                JOptionPane.showMessageDialog(this, "Paciente actualizado correctamente");

                fId.setText(""); fTel.setText(""); fDir.setText("");
                recargarListas(); // Actualiza la JList si cambió el nombre

            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        return panel;
    }

    // crear Panel Registrar Medico()

    private JPanel crearPanelRegistrarMedico() {
        JPanel panel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();

        JLabel lNom = new JLabel("Nombre:");
        JTextField fNom = new JTextField(20);
        JLabel lCed = new JLabel("Cédula:");
        JTextField fCed = new JTextField(10);
        JLabel lTel = new JLabel("Teléfono:");
        JTextField fTel = new JTextField(10);
        JLabel lDir = new JLabel("Dirección:");
        JTextField fDir = new JTextField(20);
        JLabel lEsp = new JLabel("Especialidad:");
        JComboBox<String> comboEsp = new JComboBox<>(new String[]{
                "Medicina General", "Pediatría", "Cardiología", "Ginecología", "Dermatología"
        });
        JLabel lHi = new JLabel("Horario Inicio (HH:mm):");
        JTextField fHi = new JTextField(10);
        JLabel lHf = new JLabel("Horario Fin (HH:mm):");
        JTextField fHf = new JTextField(10);
        JButton bReg = new JButton("Registrar Médico");

        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.anchor = GridBagConstraints.WEST;

        int y = 0;
        panel.add(lNom, gbc); gbc.gridx = 1; panel.add(fNom, gbc); gbc.gridx = 0; gbc.gridy = ++y;
        panel.add(lCed, gbc); gbc.gridx = 1; panel.add(fCed, gbc); gbc.gridx = 0; gbc.gridy = ++y;
        panel.add(lEsp, gbc); gbc.gridx = 1; panel.add(comboEsp, gbc); gbc.gridx = 0; gbc.gridy = ++y;
        panel.add(lTel, gbc); gbc.gridx = 1; panel.add(fTel, gbc); gbc.gridx = 0; gbc.gridy = ++y;
        panel.add(lDir, gbc); gbc.gridx = 1; panel.add(fDir, gbc); gbc.gridx = 0; gbc.gridy = ++y;
        panel.add(lHi, gbc); gbc.gridx = 1; panel.add(fHi, gbc); gbc.gridx = 0; gbc.gridy = ++y;
        panel.add(lHf, gbc); gbc.gridx = 1; panel.add(fHf, gbc); gbc.gridx = 1; gbc.gridy = ++y;
        gbc.anchor = GridBagConstraints.CENTER;
        panel.add(bReg, gbc);

        bReg.addActionListener(e -> {
            try {
                String nombre = fNom.getText().trim();
                if (!nombre.matches("(?i)[a-záéíóúñü.\\s]+"))
                    throw new IllegalArgumentException("El nombre solo puede contener letras y espacios.");

                String cedula = fCed.getText().trim();
                if (!cedula.matches("\\d{10}"))
                    throw new IllegalArgumentException("La cédula debe tener 10 dígitos.");
                if (sistema.cedulaExiste(cedula))
                    throw new IllegalArgumentException("Ya existe una persona con esa cédula.");

                String telefono = fTel.getText().trim();
                if (!telefono.matches("\\d+"))
                    throw new IllegalArgumentException("El teléfono debe contener solo números.");

                String direccion = fDir.getText().trim();
                if (direccion.isEmpty())
                    throw new IllegalArgumentException("La dirección no puede estar vacía.");

                String textoInicio = fHi.getText().trim();
                String textoFin = fHf.getText().trim();

                if (textoInicio.isEmpty() || textoFin.isEmpty()) {
                    throw new IllegalArgumentException("No se puede dejar el horario en blanco.");
                }

                LocalTime inicio = LocalTime.parse(textoInicio);
                LocalTime fin = LocalTime.parse(textoFin);

                if (fin.isBefore(inicio)) {
                    throw new IllegalArgumentException("La hora de fin no puede ser antes de la hora de inicio.");
                }


                // Aquí se genera solo una vez el ID y se usa
                int id = sistema.generarNuevoIdMedico();
                Medico m = new Medico(id, "Dr. " + nombre, cedula, telefono, direccion,
                        (String) comboEsp.getSelectedItem(), inicio, fin);
                sistema.agregarMedico(m);
                recargarListas();

                JOptionPane.showMessageDialog(this,
                        "Médico registrado correctamente con ID: " + m.getId());

                // Limpiar campos
                fNom.setText(""); fCed.setText(""); fTel.setText("");
                fDir.setText(""); fHi.setText(""); fHf.setText("");
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        return panel;
    }


    // crearPanelRegistrarPaciente()

    private JPanel crearPanelRegistrarPaciente() {
        JPanel panel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();

        JLabel lNom = new JLabel("Nombre:");
        JTextField fNom = new JTextField(20);
        JLabel lCed = new JLabel("Cédula:");
        JTextField fCed = new JTextField(15);
        JLabel lTel = new JLabel("Teléfono:");
        JTextField fTel = new JTextField(15);
        JLabel lDir = new JLabel("Dirección:");
        JTextField fDir = new JTextField(20);
        JLabel lHist = new JLabel("Historial Médico:");
        JTextField fHist = new JTextField(30);
        JButton bReg = new JButton("Registrar Paciente");

        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.anchor = GridBagConstraints.WEST;

        int y = 0;
        panel.add(lNom, gbc); gbc.gridx = 1; panel.add(fNom, gbc); gbc.gridx = 0; gbc.gridy = ++y;
        panel.add(lCed, gbc); gbc.gridx = 1; panel.add(fCed, gbc); gbc.gridx = 0; gbc.gridy = ++y;
        panel.add(lTel, gbc); gbc.gridx = 1; panel.add(fTel, gbc); gbc.gridx = 0; gbc.gridy = ++y;
        panel.add(lDir, gbc); gbc.gridx = 1; panel.add(fDir, gbc); gbc.gridx = 0; gbc.gridy = ++y;
        panel.add(lHist, gbc); gbc.gridx = 1; panel.add(fHist, gbc); gbc.gridx = 1; gbc.gridy = ++y;
        gbc.anchor = GridBagConstraints.CENTER;
        panel.add(bReg, gbc);

        bReg.addActionListener(e -> {
            try {
                String nombre = fNom.getText().trim();
                if (!nombre.matches("[a-zA-ZáéíóúÁÉÍÓÚñÑ.\\s]+"))
                    throw new IllegalArgumentException("El nombre solo puede contener letras y espacios.");

                String cedula = fCed.getText().trim();
                if (!cedula.matches("\\d{10}"))
                    throw new IllegalArgumentException("La cédula debe contener exactamente 10 dígitos.");
                if (sistema.cedulaExiste(cedula))
                    throw new IllegalArgumentException("Ya existe una persona con esa cédula.");

                String telefono = fTel.getText().trim();
                if (!telefono.matches("\\d+"))
                    throw new IllegalArgumentException("El teléfono debe contener solo números.");

                String direccion = fDir.getText().trim();
                String historial = fHist.getText().trim();

                // Generar ID y registrar
                int id = sistema.generarNuevoIdPaciente();
                Paciente p = new Paciente(id, nombre, cedula, telefono, direccion, historial);
                sistema.agregarPaciente(p);
                recargarListas();

                JOptionPane.showMessageDialog(this,
                        "Paciente registrado correctamente con ID: " + p.getId());

                fNom.setText(""); fCed.setText(""); fTel.setText("");
                fDir.setText(""); fHist.setText("");
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        return panel;
    }


    // crearPanelAsignarCita()

    private JPanel crearPanelAsignarCita() {
        JPanel panel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();

        JLabel lMedico = new JLabel("Seleccionar Médico:");
        JComboBox<Medico> comboMedicos = new JComboBox<>();

        JLabel lPaciente = new JLabel("Seleccionar Paciente:");
        JComboBox<Paciente> comboPacientes = new JComboBox<>();

        JLabel lFecha = new JLabel("Fecha (YYYY-MM-DD):");
        JTextField fFecha = new JTextField(10);

        JLabel lHora = new JLabel("Hora (HH:mm):");
        JTextField fHora = new JTextField(10);

        JButton bAsignar = new JButton("Asignar Cita");

        gbc.insets = new Insets(5,5,5,5);
        gbc.anchor = GridBagConstraints.WEST;

        gbc.gridx = 0; gbc.gridy = 0; panel.add(lMedico, gbc);
        gbc.gridx = 1; panel.add(comboMedicos, gbc);

        gbc.gridx = 0; gbc.gridy = 1; panel.add(lPaciente, gbc);
        gbc.gridx = 1; panel.add(comboPacientes, gbc);

        gbc.gridx = 0; gbc.gridy = 2; panel.add(lFecha, gbc);
        gbc.gridx = 1; panel.add(fFecha, gbc);

        gbc.gridx = 0; gbc.gridy = 3; panel.add(lHora, gbc);
        gbc.gridx = 1; panel.add(fHora, gbc);

        gbc.gridx = 1; gbc.gridy = 4; gbc.anchor = GridBagConstraints.CENTER;
        panel.add(bAsignar, gbc);

        comboMedicos.removeAllItems();
        for (Medico m : sistema.obtenerTodosMedicos()) {
            if (!m.isAusente()) comboMedicos.addItem(m);
        }

        comboPacientes.removeAllItems();
        for (Paciente p : sistema.obtenerTodosPacientes()) {
            if (p.isActivo()) comboPacientes.addItem(p);
        }

        bAsignar.addActionListener(e -> {
            try {
                Medico m = (Medico) comboMedicos.getSelectedItem();
                Paciente p = (Paciente) comboPacientes.getSelectedItem();

                if (m == null || p == null)
                    throw new IllegalArgumentException("Debe seleccionar un médico y un paciente válido.");

                LocalDate fecha = LocalDate.parse(fFecha.getText().trim());
                if (fecha.isBefore(LocalDate.now())) {
                    throw new IllegalArgumentException("No se puede asignar una cita en una fecha pasada.");
                }

                //  Verificar si el paciente ya tiene cita el mismo día
                boolean yaTieneCita = p.getHistoriaClinica().getCitas().stream()
                        .anyMatch(c -> c.getFecha().equals(fecha));

                if (yaTieneCita) {
                    int opcion = JOptionPane.showConfirmDialog(this,
                            "Este paciente ya tiene una cita el día de hoy.\n¿Desea continuar?",
                            "Advertencia",
                            JOptionPane.YES_NO_OPTION,
                            JOptionPane.WARNING_MESSAGE);
                    if (opcion != JOptionPane.YES_OPTION) {
                        return;  // El usuario eligió "No", se cancela la asignación
                    }
                }

                LocalTime hora = LocalTime.parse(fHora.getText().trim());

                if (hora.getMinute() != 0) {
                    throw new IllegalArgumentException("Las citas deben asignarse en horas exactas (por ejemplo: 09:00, 10:00).");
                }

                // Validar hora de almuerzo
                if (!hora.isBefore(LocalTime.of(12, 0)) && hora.isBefore(LocalTime.of(13, 0))) {
                    throw new IllegalArgumentException("No se puede asignar una cita durante la hora de almuerzo (12:00–13:00).");
                }

                // Validar horario del médico
                LocalTime inicio = m.getHorarioInicio();
                LocalTime fin = m.getHorarioFin().minusHours(1); // última cita una hora antes

                if (hora.isBefore(inicio) || hora.isAfter(fin)) {
                    throw new IllegalArgumentException("Hora fuera del horario disponible del médico.\nHorario válido: " + inicio + " a " + fin);
                }

                int idCita = sistema.generarNuevoIdCita();
                sistema.crearCita(idCita, fecha, hora, m.getId(), p.getId());

                JOptionPane.showMessageDialog(this,
                        "Cita asignada correctamente\n\n" +
                                "ID: " + idCita +
                                "\nMédico: " + m.getNombre() +
                                "\nEspecialidad: " + m.getEspecialidad() +
                                "\nPaciente: " + p.getNombre() +
                                "\nFecha: " + fecha +
                                "\nHora: " + hora,
                        "Éxito", JOptionPane.INFORMATION_MESSAGE);

                fFecha.setText("");
                fHora.setText("");

            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        return panel;
    }


    // crearPanelConsultarDisponibilidad()

    private JPanel crearPanelConsultarDisponibilidad() {
        JPanel panel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();

        JLabel lMedico = new JLabel("Seleccione Médico:");
        JComboBox<Medico> comboMedicos = new JComboBox<>();
        for (Medico m : sistema.obtenerTodosMedicos()) {
            comboMedicos.addItem(m);
        }

        JLabel lF = new JLabel("Fecha (YYYY-MM-DD):");
        JTextField fF = new JTextField(10);

        JLabel lH = new JLabel("Hora (HH:mm):");
        JTextField fH = new JTextField(10);

        JButton bCon = new JButton("Consultar Disponibilidad");

        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.anchor = GridBagConstraints.WEST;

        gbc.gridx = 0; gbc.gridy = 0; panel.add(lMedico, gbc);
        gbc.gridx = 1; panel.add(comboMedicos, gbc);

        gbc.gridx = 0; gbc.gridy = 1; panel.add(lF, gbc);
        gbc.gridx = 1; panel.add(fF, gbc);

        gbc.gridx = 0; gbc.gridy = 2; panel.add(lH, gbc);
        gbc.gridx = 1; panel.add(fH, gbc);

        gbc.gridx = 1; gbc.gridy = 3; gbc.anchor = GridBagConstraints.CENTER;
        panel.add(bCon, gbc);

        bCon.addActionListener(e -> {
            try {
                Medico m = (Medico) comboMedicos.getSelectedItem();
                if (m == null) throw new IllegalArgumentException("Debe seleccionar un médico.");

                LocalDate fechaConsulta = LocalDate.parse(fF.getText().trim());
                if (fechaConsulta.isBefore(LocalDate.now())) {
                    throw new IllegalArgumentException("No se puede consultar disponibilidad en fechas pasadas.");
                }

                LocalTime horaConsulta = LocalTime.parse(fH.getText().trim());

                if (horaConsulta.isAfter(LocalTime.of(12, 0).minusSeconds(1)) &&
                        horaConsulta.isBefore(LocalTime.of(13, 0))) {
                    JOptionPane.showMessageDialog(this,
                            "Médico en horario de almuerzo", "No disponible", JOptionPane.INFORMATION_MESSAGE);
                    return;
                }

                if (!m.estaDisponible(horaConsulta)) {
                    JOptionPane.showMessageDialog(this,
                            "Médico fuera de horario", "No disponible", JOptionPane.INFORMATION_MESSAGE);
                    return;
                }

                boolean ocupado = m.getCitas().stream()
                        .filter(c -> c.getFecha().equals(fechaConsulta))
                        .anyMatch(c -> Math.abs(Duration.between(c.getHora(), horaConsulta).toMinutes()) < 60);

                JOptionPane.showMessageDialog(this,
                        ocupado ? "Cita cercana. NO disponible" : "Disponible",
                        ocupado ? "No disponible" : "Disponible", JOptionPane.INFORMATION_MESSAGE);

            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this,
                        ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        return panel;
    }

    // crearPanelMostrarCitasMedico()

    private JPanel crearPanelMostrarCitasMedico() {
        JPanel panel = new JPanel(new BorderLayout());

        // Parte superior: campo ID y botón buscar
        JPanel top = new JPanel();
        top.add(new JLabel("ID Médico:"));
        JTextField fId = new JTextField(10);
        top.add(fId);
        JButton bMostrar = new JButton("Mostrar Citas");
        top.add(bMostrar);
        panel.add(top, BorderLayout.NORTH);

        // Área de texto para mostrar citas
        JTextArea area = new JTextArea(15, 30);
        area.setEditable(false);
        JScrollPane scrollArea = new JScrollPane(area);
        panel.add(scrollArea, BorderLayout.CENTER);

        // Lista de médicos a la izquierda
        DefaultListModel<String> modeloLista = new DefaultListModel<>();
        JList<String> listaMedicos = new JList<>(modeloLista);
        JScrollPane scrollLista = new JScrollPane(listaMedicos);
        scrollLista.setBorder(BorderFactory.createTitledBorder("Médicos Registrados"));
        scrollLista.setPreferredSize(new Dimension(200, 200));
        panel.add(scrollLista, BorderLayout.WEST);

        // Llenar lista con los médicos
        for (Medico m : sistema.obtenerTodosMedicos()) {
            modeloLista.addElement(m.getId() + ": " + m.getNombre());
        }

        // Al seleccionar un médico, llenar campo ID
        listaMedicos.addListSelectionListener(e -> {
            String seleccion = listaMedicos.getSelectedValue();
            if (seleccion != null && seleccion.contains(":")) {
                String idSeleccionado = seleccion.split(":")[0].trim();
                fId.setText(idSeleccionado);
            }
        });

        // Acción de mostrar citas
        bMostrar.addActionListener(e -> {
            try {
                int id = Integer.parseInt(fId.getText().trim());
                Medico m = sistema.obtenerMedico(id);
                if (m == null) {
                    area.setText("Médico no encontrado.");
                    return;
                }

                StringBuilder sb = new StringBuilder();
                sb.append("ID Médico: ").append(m.getId()).append("\n")
                        .append("Nombre: ").append(m.getNombre()).append("\n")
                        .append("Especialidad: ").append(m.getEspecialidad()).append("\n")
                        .append("Horario de Atención: ").append(m.getHorarioInicio())
                        .append(" – ").append(m.getHorarioFin()).append("\n")
                        .append("Estado: ").append(m.isAusente() ? "INACTIVO (Ausente)" : "ACTIVO (Presente)").append("\n\n");

                List<Cita> lista = m.getCitas();
                if (lista.isEmpty()) {
                    sb.append("No hay citas registradas para este médico.");
                } else {
                    for (Cita c : lista) {
                        String estadoCita = c.isCancelada() ? "CANCELADA" : "ACTIVA";
                        sb.append(String.format(
                                "Cita %d: %s %s – Paciente: %s – Estado: %s\n",
                                c.getIdCita(), c.getFecha(), c.getHora(),
                                c.getPaciente().getNombre(),
                                estadoCita
                        ));
                    }
                }

                area.setText(sb.toString());

            } catch (NumberFormatException ex) {
                area.setText("El ID debe ser un número válido.");
            }
        });

        return panel;
    }



    // crearPanelMostrarCitasPaciente()
    private JPanel crearPanelMostrarCitasPaciente() {
        JPanel panel = new JPanel(new BorderLayout());

        // Panel superior con campo ID y botón
        JPanel top = new JPanel();
        top.add(new JLabel("ID Paciente:"));
        JTextField fId = new JTextField(10);
        top.add(fId);
        JButton bMostrar = new JButton("Mostrar Citas");
        top.add(bMostrar);
        panel.add(top, BorderLayout.NORTH);

        // Área de texto para mostrar citas
        JTextArea area = new JTextArea(15, 30);
        area.setEditable(false);
        JScrollPane scrollArea = new JScrollPane(area);
        panel.add(scrollArea, BorderLayout.CENTER);

        // Lista de pacientes a la izquierda
        DefaultListModel<String> modeloLista = new DefaultListModel<>();
        JList<String> listaPacientes = new JList<>(modeloLista);
        JScrollPane scrollLista = new JScrollPane(listaPacientes);
        scrollLista.setBorder(BorderFactory.createTitledBorder("Pacientes Registrados"));
        scrollLista.setPreferredSize(new Dimension(200, 200));
        panel.add(scrollLista, BorderLayout.WEST);

        // Llenar lista con los pacientes
        for (Paciente p : sistema.obtenerTodosPacientes()) {
            modeloLista.addElement(p.getId() + ": " + p.getNombre());
        }

        // Al seleccionar un paciente de la lista, llenar el campo ID
        listaPacientes.addListSelectionListener(e -> {
            String seleccion = listaPacientes.getSelectedValue();
            if (seleccion != null && seleccion.contains(":")) {
                String idSeleccionado = seleccion.split(":")[0].trim();
                fId.setText(idSeleccionado);
            }
        });

        // Acción del botón Mostrar
        bMostrar.addActionListener(e -> {
            try {
                int id = Integer.parseInt(fId.getText().trim());
                Paciente p = sistema.obtenerPaciente(id);
                if (p == null) {
                    area.setText("Paciente no encontrado.");
                    return;
                }

                StringBuilder sb = new StringBuilder();
                sb.append("ID Paciente: ").append(p.getId()).append("\n")
                        .append("Nombre: ").append(p.getNombre()).append("\n")
                        .append("Cédula: ").append(p.getCedula()).append("\n")
                        .append("Teléfono: ").append(p.getTelefono()).append("\n")
                        .append("Dirección: ").append(p.getDireccion()).append("\n")
                        .append("Historia Clínica:\n").append(p.getHistoriaMedica()).append("\n\n");

                List<Cita> lista = p.getCitas();
                lista.sort(Comparator.comparing(Cita::getFecha).thenComparing(Cita::getHora));

                if (lista.isEmpty()) {
                    sb.append("No hay citas registradas.");
                } else {
                    for (Cita c : lista) {
                        String estado = c.isCancelada() ? "CANCELADA (Paciente)" :
                                (c.getMedico().isAusente() ? "CANCELADA (Médico)" : "ACTIVA");
                        sb.append(String.format(
                                "Cita %d: %s %s – Médico: %s – Estado: %s\n",
                                c.getIdCita(),
                                c.getFecha(),
                                c.getHora(),
                                c.getMedico().getNombre(),
                                estado
                        ));
                    }
                }

                area.setText(sb.toString());

            } catch (NumberFormatException ex) {
                area.setText("ID debe ser un número entero.");
            }
        });

        return panel;
    }

    // crearPanelCancelarCitaPaciente()

    private JPanel crearPanelCancelarCitaPaciente() {
        JPanel panel = new JPanel(new BorderLayout());

        // Panel superior con campo ID y botón Buscar
        JPanel top = new JPanel(new FlowLayout(FlowLayout.LEFT));
        top.add(new JLabel("ID Paciente:"));
        JTextField fId = new JTextField(10);
        JButton bBuscar = new JButton("Buscar Citas Activas");
        top.add(fId);
        top.add(bBuscar);

        //  Lista de pacientes
        DefaultListModel<String> modeloPacientes = new DefaultListModel<>();
        JList<String> listaPacientes = new JList<>(modeloPacientes);
        listaPacientes.setVisibleRowCount(5);
        JScrollPane scrollPacientes = new JScrollPane(listaPacientes);
        scrollPacientes.setBorder(BorderFactory.createTitledBorder("Pacientes Registrados"));

        for (Paciente p : sistema.obtenerTodosPacientes()) {
            modeloPacientes.addElement(p.getId() + ": " + p.getNombre());
        }

        listaPacientes.addListSelectionListener(e -> {
            String seleccion = listaPacientes.getSelectedValue();
            if (seleccion != null && seleccion.contains(":")) {
                String idSeleccionado = seleccion.split(":")[0].trim();
                fId.setText(idSeleccionado);
            }
        });

        JPanel panelIzquierdo = new JPanel(new BorderLayout());
        panelIzquierdo.add(scrollPacientes, BorderLayout.CENTER);
        panelIzquierdo.add(top, BorderLayout.SOUTH);

        panel.add(panelIzquierdo, BorderLayout.WEST);

        // Lista de citas activas
        DefaultListModel<Cita> modeloCitas = new DefaultListModel<>();
        JList<Cita> listaCitas = new JList<>(modeloCitas);
        listaCitas.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        JScrollPane scrollCitas = new JScrollPane(listaCitas);
        scrollCitas.setBorder(BorderFactory.createTitledBorder("Seleccione una cita para cancelar"));
        panel.add(scrollCitas, BorderLayout.CENTER);

        // Botón para cancelar
        JButton bCancelar = new JButton("Cancelar Cita");
        panel.add(bCancelar, BorderLayout.SOUTH);

        // Acción Buscar
        bBuscar.addActionListener(e -> {
            try {
                int id = Integer.parseInt(fId.getText().trim());
                Paciente p = sistema.obtenerPaciente(id);
                if (p == null) {
                    JOptionPane.showMessageDialog(this, "Paciente no encontrado.");
                    return;
                }

                modeloCitas.clear();
                for (Cita c : p.getCitas()) {
                    if (!c.isCancelada()) {
                        modeloCitas.addElement(c);
                    }
                }

                if (modeloCitas.isEmpty()) {
                    JOptionPane.showMessageDialog(this, "Este paciente no tiene citas activas.");
                }

            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "ID inválido.");
            }
        });

        // Acción Cancelar Cita
        bCancelar.addActionListener(e -> {
            Cita seleccionada = listaCitas.getSelectedValue();
            if (seleccionada == null) {
                JOptionPane.showMessageDialog(this, "Seleccione una cita para cancelar.");
                return;
            }

            int confirm = JOptionPane.showConfirmDialog(this,
                    "¿Está seguro de cancelar esta cita?", "Confirmación", JOptionPane.YES_NO_OPTION);

            if (confirm == JOptionPane.YES_OPTION) {
                seleccionada.cancelar();
                JOptionPane.showMessageDialog(this, "Cita cancelada correctamente.");
                modeloCitas.removeElement(seleccionada);
            }
        });

        return panel;
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new VentanaPrincipal().setVisible(true));
    }

    private void recargarListas() {
        modeloMedicos.clear();
        for (Medico m : sistema.obtenerTodosMedicos()) {
            modeloMedicos.addElement(
                    m.getId() + ": " + m.getNombre()
                            + " – " + m.getEspecialidad()
                            + " (" + m.getHorarioInicio() + "–" + m.getHorarioFin() + ")"
                            + " – Estado: " + (m.isAusente() ? "AUSENTE" : "ACTIVO")
            );
        }

        modeloPacientes.clear();
        for (Paciente p : sistema.obtenerTodosPacientes()) {
            modeloPacientes.addElement(
                    p.getId() + ": " + p.getNombre()
            );
        }
    }

}
