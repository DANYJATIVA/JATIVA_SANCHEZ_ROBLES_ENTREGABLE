package entregable.negocio;

import java.time.LocalDate;
import java.time.LocalTime;

public class Cita {
    private int idCita;
    private LocalDate fecha;
    private LocalTime hora;
    private Medico medico;
    private Paciente paciente;
    private boolean cancelada = false;

    public Cita(int idCita, LocalDate fecha, LocalTime hora, Medico medico, Paciente paciente) {
        if (fecha == null || hora == null || medico == null || paciente == null)
            throw new IllegalArgumentException("Ningún dato puede ser nulo");

        this.idCita = idCita;
        this.fecha = fecha;
        this.hora = hora;
        this.medico = medico;
        this.paciente = paciente;

        medico.agregarCita(this);
        paciente.getHistoriaClinica().agregarCita(this);
    }

    public int getIdCita() { return idCita; }
    public LocalDate getFecha() { return fecha; }
    public LocalTime getHora() { return hora; }
    public Medico getMedico() { return medico; }
    public Paciente getPaciente() { return paciente; }

    public boolean isCancelada() { return cancelada; }
    public void cancelar() { this.cancelada = true; }

    @Override
    public String toString() {
        String estado = isCancelada() ? "CANCELADA" :
                (medico.isAusente() ? "CANCELADA (Médico)" : "ACTIVA");

        return String.format("Cita %d: %s %s – Médico: %s – Estado: %s",
                idCita, fecha, hora, medico.getNombre(), estado);
    }
}
