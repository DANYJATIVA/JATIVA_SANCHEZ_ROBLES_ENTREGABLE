package entregable.negocio;

import java.util.List;

public class Paciente extends Persona {
    private static int contadorId = 9000;
    private boolean activo = true;
    private HistoriaClinica historiaClinica = new HistoriaClinica();

    public Paciente(int id, String nombre, String cedula, String telefono,
                    String direccion, String entradaInicial) {
        super(contadorId++, nombre, cedula, telefono, direccion);
        if (entradaInicial != null && !entradaInicial.trim().isEmpty())
            this.historiaClinica.agregarEntrada(entradaInicial);
    }

    public HistoriaClinica getHistoriaClinica() { return historiaClinica; }
    public void agregarEntradaHistoria(String entrada) { historiaClinica.agregarEntrada(entrada); }
    public void agregarCita(Cita c) { historiaClinica.agregarCita(c); }
    public List<Cita> getCitas() { return historiaClinica.getCitas(); }
    public String getHistoriaMedica() { return historiaClinica.obtenerHistoriaCompleta(); }

    public boolean isActivo() { return activo; }
    public void desactivar() { activo = false; }
    public void activar() { activo = true; }

    public void actualizarDatos(String nombre, String telefono, String direccion) {
        if (nombre != null && !nombre.trim().isEmpty()) {
            if (!nombre.trim().matches("(?i)[a-záéíóúñü\\s]+"))
                throw new IllegalArgumentException("El nombre solo puede contener letras y espacios.");
            this.nombre = nombre.trim();
        }

        if (telefono != null && !telefono.trim().isEmpty()) {
            if (!telefono.trim().matches("\\d+"))
                throw new IllegalArgumentException("El teléfono debe contener solo números.");
            this.telefono = telefono.trim();
        }

        if (direccion != null && !direccion.trim().isEmpty()) {
            this.direccion = direccion.trim();
        }
    }

    @Override
    public String toString() {
        return String.format("%s (ID: %d)", getNombre(), getId());
    }

}
