package entregable.negocio;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

public class HistoriaClinica {
    private List<Cita> citas = new ArrayList<>();
    private List<EntradaClinica> entradas = new ArrayList<>();

    // Clase interna que representa una entrada con fecha
    private static class EntradaClinica {
        private final String texto;
        private final LocalDate fecha;

        public EntradaClinica(String texto) {
            this.texto = texto;
            this.fecha = LocalDate.now();
        }

        public String formatear() {
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
            return String.format("[%s] %s", fecha.format(formatter), texto);
        }
    }

    // Agregar una nota o entrada médica
    public void agregarEntrada(String entrada) {
        if (entrada == null || entrada.trim().isEmpty())
            throw new IllegalArgumentException("La entrada de historia clínica no puede estar vacía");
        entradas.add(new EntradaClinica(entrada.trim()));
    }

    // Agregar una cita a la historia
    public void agregarCita(Cita cita) {
        if (cita == null) throw new IllegalArgumentException("La cita no puede ser nula.");
        citas.add(cita);
    }

    // Obtener lista de todas las citas asociadas a esta historia clínica
    public List<Cita> getCitas() {
        return citas;
    }

    // Verifica si hay entradas en la historia
    public boolean tieneEntradas() {
        return !entradas.isEmpty();
    }

    // Devuelve la historia clínica como texto con formato
    public String obtenerHistoriaCompleta() {
        if (entradas.isEmpty()) return "";
        StringBuilder sb = new StringBuilder();
        for (EntradaClinica e : entradas) {
            sb.append("- ").append(e.formatear()).append("\n");
        }
        return sb.toString().trim();
    }
}
