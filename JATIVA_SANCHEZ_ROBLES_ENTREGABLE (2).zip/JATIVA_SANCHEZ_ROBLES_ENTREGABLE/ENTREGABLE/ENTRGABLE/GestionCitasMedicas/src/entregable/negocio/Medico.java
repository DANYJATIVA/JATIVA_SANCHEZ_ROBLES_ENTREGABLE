package entregable.negocio;

import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;

public class Medico extends Persona {
    private static int contadorId = 1000;
    private String especialidad;
    private LocalTime horarioInicio;
    private LocalTime horarioFin;
    private boolean ausente = false;
    private List<Cita> citas = new ArrayList<>();

    public Medico(int id, String nombre, String cedula, String telefono, String direccion,
                  String especialidad, LocalTime horarioInicio, LocalTime horarioFin) {
        super(contadorId++, nombre, cedula, telefono, direccion);
        if (horarioFin.isBefore(horarioInicio))
            throw new IllegalArgumentException("Horario fin debe ser posterior al inicio");
        this.especialidad = especialidad;
        this.horarioInicio = horarioInicio;
        this.horarioFin = horarioFin;
    }

    public String getEspecialidad() { return especialidad; }
    public LocalTime getHorarioInicio() { return horarioInicio; }
    public LocalTime getHorarioFin() { return horarioFin; }
    public boolean isAusente() { return ausente; }

    public void setEspecialidad(String especialidad) { this.especialidad = especialidad; }
    public void setHorarioInicio(LocalTime horarioInicio) { this.horarioInicio = horarioInicio; }
    public void setHorarioFin(LocalTime horarioFin) { this.horarioFin = horarioFin; }
    public void setAusente(boolean ausente) { this.ausente = ausente; }

    public void agregarCita(Cita cita) { citas.add(cita); }
    public List<Cita> getCitas() { return citas; }

    public boolean estaDisponible(LocalTime hora) {
        if (ausente) return false;
        if (hora.isAfter(LocalTime.of(12, 0)) && hora.isBefore(LocalTime.of(13, 0))) return false;
        return !hora.isBefore(horarioInicio) && !hora.isAfter(horarioFin);
    }

    @Override
    public String toString() {
        return String.format("%s (ID: %d, %s)", getNombre(), getId(), getEspecialidad());
    }


}
