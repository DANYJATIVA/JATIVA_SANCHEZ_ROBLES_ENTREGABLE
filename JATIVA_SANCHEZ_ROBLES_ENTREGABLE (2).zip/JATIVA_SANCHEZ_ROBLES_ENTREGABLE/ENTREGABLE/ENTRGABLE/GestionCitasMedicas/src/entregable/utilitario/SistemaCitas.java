package entregable.utilitario;

import entregable.negocio.Cita;
import entregable.negocio.Medico;
import entregable.negocio.Paciente;

import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.*;

public class SistemaCitas {
    private Map<Integer, Medico> medicos = new HashMap<>();
    private Map<Integer, Paciente> pacientes = new HashMap<>();
    private Map<Integer, Cita> citas = new HashMap<>();
    private int ultimoIdCita = 9000;

    public SistemaCitas() {
        agregarMedico(new Medico(
                generarNuevoIdMedico(),
                "Dr. Dany Jativa", "0000000001", "0991111111", "Av. Salud", "General",
                LocalTime.of(8, 0), LocalTime.of(18, 0)
        ));

        agregarMedico(new Medico(
                generarNuevoIdMedico(),
                "Dr. Tomas Sanchez", "0000000002", "0992222222", "Av. Vida", "Pediatría",
                LocalTime.of(8, 0), LocalTime.of(18, 0)
        ));

        agregarMedico(new Medico(
                generarNuevoIdMedico(),
                "Dr. Darwin Robles", "0000000003", "0993333333", "Av. Corazón", "Cardiología",
                LocalTime.of(8, 0), LocalTime.of(18, 0)
        ));

        agregarPaciente(new Paciente(
                generarNuevoIdPaciente(),
                "Ana Pérez", "0102030405", "0998887777", "Calle Norte", "Diabética tipo II"
        ));

        agregarPaciente(new Paciente(
                generarNuevoIdPaciente(),
                "Luis Gómez", "0203040506", "0987654321", "Calle Sur", "Hipertensión controlada"
        ));
    }

    public boolean cedulaExiste(String cedula) {
        return medicos.values().stream().anyMatch(m -> m.getCedula().equals(cedula)) ||
                pacientes.values().stream().anyMatch(p -> p.getCedula().equals(cedula));
    }

    public void agregarMedico(Medico m) {
        if (cedulaExiste(m.getCedula()))
            throw new IllegalArgumentException("Ya existe una persona registrada con esa cédula");
        medicos.put(m.getId(), m);
    }

    public void agregarPaciente(Paciente p) {
        if (cedulaExiste(p.getCedula()))
            throw new IllegalArgumentException("Ya existe una persona registrada con esa cédula");
        pacientes.put(p.getId(), p);
    }

    public Medico obtenerMedico(int id) {
        return medicos.get(id);
    }

    public Paciente obtenerPaciente(int id) {
        return pacientes.get(id);
    }

    public int generarNuevoIdMedico() {
        int id = 1;
        while (medicos.containsKey(id)) id++;
        return id;
    }

    public int generarNuevoIdPaciente() {
        int id = 1;
        while (pacientes.containsKey(id)) id++;
        return id;
    }

    public int generarNuevoIdCita() {
        return ++ultimoIdCita;
    }

    public List<Medico> obtenerTodosMedicos() {
        return new ArrayList<>(medicos.values());
    }

    public List<Paciente> obtenerTodosPacientes() {
        return new ArrayList<>(pacientes.values());
    }



    public void crearCita(int idCita, LocalDate fecha, LocalTime hora, int idMedico, int idPaciente) {
        if (citas.containsKey(idCita))
            throw new IllegalArgumentException("Ya existe una cita con ese ID");

        Medico m = medicos.get(idMedico);
        if (m == null) throw new IllegalArgumentException("Médico no existe");

        if (!m.estaDisponible(hora))
            throw new IllegalArgumentException("Médico fuera de horario o ausente");

        if (hora.isAfter(LocalTime.of(12, 0)) && hora.isBefore(LocalTime.of(13, 0)))
            throw new IllegalArgumentException("Horario de almuerzo. No disponible");

        // Validar que la hora esté dentro del horario permitido
        if (hora.isBefore(m.getHorarioInicio()) || hora.isAfter(m.getHorarioFin().minusHours(1))) {
            throw new IllegalArgumentException("Hora fuera del horario del médico");
        }

        Paciente p = pacientes.get(idPaciente);
        if (p == null || !p.isActivo())
            throw new IllegalArgumentException("Paciente no válido");

        if (!p.getHistoriaClinica().tieneEntradas())
            throw new IllegalArgumentException("Sin historia clínica");


        // Validar duplicamiento con otras citas del médico
        for (Cita c : m.getCitas()) {
            if (c.getFecha().equals(fecha) &&
                    Math.abs(Duration.between(c.getHora(), hora).toMinutes()) < 60) {
                throw new IllegalArgumentException("Cita duplicada con el médico en esa hora");
            }
        }



        Cita nueva = new Cita(idCita, fecha, hora, m, p);
        citas.put(idCita, nueva);
    }

        //actualizar datos del médico

    public void actualizarDatosMedico(int id, String tel, String dir, String especialidad,
                                      LocalTime hInicio, LocalTime hFin, boolean ausente) {
        Medico m = medicos.get(id);
        if (m == null) throw new IllegalArgumentException("Médico no encontrado");

        if (tel != null && !tel.isEmpty()) m.setTelefono(tel);
        if (dir != null && !dir.isEmpty()) m.setDireccion(dir);
        if (especialidad != null && !especialidad.isEmpty()) m.setEspecialidad(especialidad);
        if (hInicio != null) m.setHorarioInicio(hInicio);
        if (hFin != null) m.setHorarioFin(hFin);
        m.setAusente(ausente);
    }

    public void editarPaciente(int id, String nuevoTelefono, String nuevaDireccion) {
        Paciente p = pacientes.get(id);
        if (p == null) throw new IllegalArgumentException("Paciente no encontrado");

        if (nuevoTelefono != null && !nuevoTelefono.trim().isEmpty())
            p.setTelefono(nuevoTelefono);
        if (nuevaDireccion != null && !nuevaDireccion.trim().isEmpty())
            p.setDireccion(nuevaDireccion);
    }
}
