package entregable.negocio;

import java.time.LocalTime;

public class Medico extends Persona {
    private String especialidad;
    private LocalTime horarioInicio;
    private LocalTime horarioFin;
    private boolean ausente = false;

    public Medico(int id, String nombre, String cedula,
                  String telefono, String direccion,
                  String especialidad,
                  LocalTime horarioInicio, LocalTime horarioFin) {
        super(id, nombre, cedula, telefono, direccion);
        if (horarioFin.isBefore(horarioInicio))
            throw new IllegalArgumentException("Horario fin debe ser posterior al inicio");
        this.especialidad = especialidad;
        this.horarioInicio = horarioInicio;
        this.horarioFin = horarioFin;
    }

    public String getEspecialidad() { return especialidad; }
    public LocalTime getHorarioInicio() { return horarioInicio; }
    public LocalTime getHorarioFin() { return horarioFin; }
    public boolean isAusente() { return ausente; }

    public void setEspecialidad(String especialidad) {
        this.especialidad = especialidad;
    }

    public void setHorarioInicio(LocalTime horarioInicio) {
        this.horarioInicio = horarioInicio;
    }

    public void setHorarioFin(LocalTime horarioFin) {
        this.horarioFin = horarioFin;
    }

    public void setAusente(boolean ausente) {
        this.ausente = ausente;
    }

    /** True si la hora está dentro de su horario laboral y no está ausente ni en almuerzo */
    public boolean estaDisponible(LocalTime hora) {
        if (ausente) return false;
        if (hora.isAfter(LocalTime.of(12, 0)) && hora.isBefore(LocalTime.of(13, 0))) return false;
        return !hora.isBefore(horarioInicio) && !hora.isAfter(horarioFin);
    }
}
