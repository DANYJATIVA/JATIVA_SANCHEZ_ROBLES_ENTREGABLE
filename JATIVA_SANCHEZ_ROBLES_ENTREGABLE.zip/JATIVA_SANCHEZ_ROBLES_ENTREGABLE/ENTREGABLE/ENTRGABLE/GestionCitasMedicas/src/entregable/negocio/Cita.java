package entregable.negocio;

import java.time.LocalDate;
import java.time.LocalTime;

public class Cita {
    private int idCita;
    private LocalDate fecha;
    private LocalTime hora;
    private Medico medico;
    private Paciente paciente;

    public Cita(int idCita, LocalDate fecha, LocalTime hora,
                Medico medico, Paciente paciente) {
        if (idCita <= 0) throw new IllegalArgumentException("ID de cita debe ser positivo");
        this.idCita = idCita;
        this.fecha = fecha;
        this.hora = hora;
        this.medico = medico;
        this.paciente = paciente;
        medico.agregarCita(this);
        paciente.agregarCita(this);
    }

    public int getIdCita() { return idCita; }
    public LocalDate getFecha() { return fecha; }
    public LocalTime getHora() { return hora; }
    public Medico getMedico() { return medico; }
    public Paciente getPaciente() { return paciente; }

    public String getHistoriaClinicaPaciente() {
        return paciente.getHistoriaMedica();
    }
}
