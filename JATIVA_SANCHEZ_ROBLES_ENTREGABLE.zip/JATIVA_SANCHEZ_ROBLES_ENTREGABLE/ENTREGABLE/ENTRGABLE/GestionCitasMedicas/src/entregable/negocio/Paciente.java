package entregable.negocio;

public class Paciente extends Persona {
    private boolean activo = true;

    public Paciente(int id, String nombre, String cedula,
                    String telefono, String direccion,
                    String entradaInicial) {
        super(id, nombre, cedula, telefono, direccion);
        if (entradaInicial != null && !entradaInicial.trim().isEmpty())
            this.historiaClinica.agregarEntrada(entradaInicial);
    }

    public String getHistoriaMedica() {
        return historiaClinica.obtenerHistoriaCompleta();
    }

    public void agregarNotaHistoria(String nota) {
        historiaClinica.agregarEntrada(nota);
    }

    public boolean isActivo() {
        return activo;
    }

    public void desactivar() {
        activo = false;
    }

    public void activar() {
        activo = true;
    }

    public void actualizarDatos(String nombre, String telefono, String direccion) {
        if (nombre != null && !nombre.trim().isEmpty()) {
            if (!nombre.trim().matches("(?i)[a-záéíóúñü\\s]+"))
                throw new IllegalArgumentException("El nombre solo puede contener letras y espacios.");
            this.nombre = nombre.trim();
        }

        if (telefono != null && !telefono.trim().isEmpty()) {
            if (!telefono.trim().matches("\\d+"))
                throw new IllegalArgumentException("El teléfono debe contener solo números.");
            this.telefono = telefono.trim();
        }

        if (direccion != null && !direccion.trim().isEmpty()) {
            this.direccion = direccion.trim();
        }
    }
}
