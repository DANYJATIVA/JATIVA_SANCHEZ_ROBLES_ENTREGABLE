package entregable.negocio;

import java.util.ArrayList;
import java.util.List;

public class HistoriaClinica {
    private List<String> entradas = new ArrayList<>();

    public void agregarEntrada(String entrada) {
        if (entrada == null || entrada.trim().isEmpty())
            throw new IllegalArgumentException("La entrada de historia clínica no puede estar vacía");
        entradas.add(entrada.trim());
    }

    public String obtenerHistoriaCompleta() {
        if (entradas.isEmpty()) return "";
        StringBuilder sb = new StringBuilder();
        for (String e : entradas) {
            sb.append("- ").append(e).append("\n");
        }
        return sb.toString().trim();
    }

    public boolean tieneEntradas() {
        return !entradas.isEmpty();
    }
}
