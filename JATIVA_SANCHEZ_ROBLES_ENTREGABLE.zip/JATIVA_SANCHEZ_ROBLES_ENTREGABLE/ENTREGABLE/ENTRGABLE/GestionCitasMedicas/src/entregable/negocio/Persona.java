package entregable.negocio;

import java.util.ArrayList;
import java.util.List;

public abstract class Persona {
    public HistoriaClinica historiaClinica;
    protected int id;
    protected String nombre;
    protected String cedula;
    protected String telefono;
    protected String direccion;
    protected List<Cita> citas = new ArrayList<>();

    public Persona(int id, String nombre, String cedula,
                   String telefono, String direccion) {
        if (id <= 0) throw new IllegalArgumentException("ID debe ser positivo");

        if (cedula == null || !cedula.matches("\\d{10}"))
            throw new IllegalArgumentException("Cédula debe ser un número de 10 dígitos");

        if (nombre == null || !nombre.trim().matches("(?i)[a-záéíóúñü.\\s]+"))
            throw new IllegalArgumentException("El nombre solo puede contener letras y espacios.");

        if (telefono != null && !telefono.matches("\\d+"))
            throw new IllegalArgumentException("El teléfono debe contener solo números");

        this.id = id;
        this.nombre = nombre.trim();
        this.cedula = cedula;
        this.telefono = telefono;
        this.direccion = direccion;

        this.historiaClinica = new HistoriaClinica();
    }

    // Getters
    public int getId() { return id; }
    public String getNombre() { return nombre; }
    public String getCedula() { return cedula; }
    public String getTelefono() { return telefono; }
    public String getDireccion() { return direccion; }

    // Setters agregados para edición
    public void setTelefono(String telefono) {
        if (telefono != null && telefono.matches("\\d+")) {
            this.telefono = telefono;
        } else {
            throw new IllegalArgumentException("El teléfono debe contener solo números.");
        }
    }

    public void setDireccion(String direccion) {
        if (direccion != null && !direccion.trim().isEmpty()) {
            this.direccion = direccion;
        } else {
            throw new IllegalArgumentException("La dirección no puede estar vacía.");
        }
    }

    // Retorna copia de la lista de citas asociadas
    public List<Cita> getCitas() {
        return new ArrayList<>(citas);
    }

    // Asociar una cita a esta persona
    protected void agregarCita(Cita c) {
        citas.add(c);
    }
}
