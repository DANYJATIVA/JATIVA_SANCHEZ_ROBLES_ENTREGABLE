package entregable.utilitario;

import entregable.negocio.Cita;
import entregable.negocio.Medico;
import entregable.negocio.Paciente;

import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.*;

public class SistemaCitas {
    private Map<Integer, Medico> medicos = new HashMap<>();
    private Map<Integer, Paciente> pacientes = new HashMap<>();
    private Map<Integer, Cita> citas = new HashMap<>();

    public SistemaCitas() {
        // Datos quemados
        agregarMedico(new Medico(1, "Dr. Dany Jativa", "0000000001", "0991111111", "Av. Salud", "General",
                LocalTime.of(8, 0), LocalTime.of(18, 0)));
        agregarMedico(new Medico(2, "Dr. Tomas Sanchez", "0000000002", "0992222222", "Av. Vida", "Pediatría",
                LocalTime.of(8, 0), LocalTime.of(18, 0)));
        agregarMedico(new Medico(3, "Dr. Darwin Robles", "0000000003", "0993333333", "Av. Corazón", "Cardiología",
                LocalTime.of(8, 0), LocalTime.of(18, 0)));

        agregarPaciente(new Paciente(10, "Ana Pérez", "0102030405", "0998887777", "Calle Norte", "Diabética tipo II"));
        agregarPaciente(new Paciente(11, "Luis Gómez", "0203040506", "0987654321", "Calle Sur", "Hipertensión controlada"));
    }

    public boolean cedulaExiste(String cedula) {
        return medicos.values().stream().anyMatch(m -> m.getCedula().equals(cedula)) ||
                pacientes.values().stream().anyMatch(p -> p.getCedula().equals(cedula));
    }

    public void agregarMedico(Medico m) {
        if (medicos.containsKey(m.getId()))
            throw new IllegalArgumentException("Ya existe un médico con ese ID");
        if (cedulaExiste(m.getCedula()))
            throw new IllegalArgumentException("Ya existe una persona registrada con esa cédula");
        medicos.put(m.getId(), m);
    }

    public void agregarPaciente(Paciente p) {
        if (pacientes.containsKey(p.getId()))
            throw new IllegalArgumentException("Ya existe un paciente con ese ID");
        if (cedulaExiste(p.getCedula()))
            throw new IllegalArgumentException("Ya existe una persona registrada con esa cédula");
        pacientes.put(p.getId(), p);
    }

    public Medico obtenerMedico(int id) {
        return medicos.get(id);
    }

    public Paciente obtenerPaciente(int id) {
        return pacientes.get(id);
    }

    public List<Medico> obtenerTodosMedicos() {
        return new ArrayList<>(medicos.values());
    }

    public List<Paciente> obtenerTodosPacientes() {
        return new ArrayList<>(pacientes.values());
    }

    public void crearCita(int idC, LocalDate f, LocalTime h, int idM, int idP) {
        if (citas.containsKey(idC))
            throw new IllegalArgumentException("ID de cita ya existe");
        Medico m = medicos.get(idM);
        if (m == null) throw new IllegalArgumentException("Médico no existe");
        if (!m.estaDisponible(h))
            throw new IllegalArgumentException("Médico fuera de horario o ausente");
        if (h.isAfter(LocalTime.of(12, 0)) && h.isBefore(LocalTime.of(13, 0)))
            throw new IllegalArgumentException("Horario de almuerzo. No disponible");

        Paciente p = pacientes.get(idP);
        if (p == null || !p.isActivo())
            throw new IllegalArgumentException("Paciente no válido");
        if (!p.historiaClinica.tieneEntradas())
            throw new IllegalArgumentException("Sin historia clínica");

        for (Cita c : m.getCitas()) {
            if (c.getFecha().equals(f) &&
                    Math.abs(Duration.between(c.getHora(), h).toMinutes()) < 60) {
                throw new IllegalArgumentException("Cita solapada");
            }
        }

        Cita c = new Cita(idC, f, h, m, p);
        citas.put(idC, c);
    }

    public void actualizarDatosMedico(int id, String tel, String dir, String especialidad,
                                      LocalTime hInicio, LocalTime hFin, boolean ausente) {
        Medico m = medicos.get(id);
        if (m == null) throw new IllegalArgumentException("Médico no encontrado");

        if (tel != null && !tel.isEmpty()) m.setTelefono(tel);
        if (dir != null && !dir.isEmpty()) m.setDireccion(dir);
        if (especialidad != null && !especialidad.isEmpty()) m.setEspecialidad(especialidad);
        if (hInicio != null) m.setHorarioInicio(hInicio);
        if (hFin != null) m.setHorarioFin(hFin);
        m.setAusente(ausente);
    }
    public void editarPaciente(int id, String nuevoTelefono, String nuevaDireccion) {
        Paciente p = pacientes.get(id);
        if (p == null) throw new IllegalArgumentException("Paciente no encontrado");
        if (nuevoTelefono != null && !nuevoTelefono.trim().isEmpty()) {
            p.setTelefono(nuevoTelefono);
        }
        if (nuevaDireccion != null && !nuevaDireccion.trim().isEmpty()) {
            p.setDireccion(nuevaDireccion);
        }
    }

}
