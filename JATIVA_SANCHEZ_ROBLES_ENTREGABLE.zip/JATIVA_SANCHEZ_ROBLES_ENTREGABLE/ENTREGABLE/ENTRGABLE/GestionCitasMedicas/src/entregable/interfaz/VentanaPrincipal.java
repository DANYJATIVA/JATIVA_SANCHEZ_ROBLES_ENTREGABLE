import entregable.negocio.Cita;
import entregable.negocio.Medico;
import entregable.negocio.Paciente;
import entregable.utilitario.SistemaCitas;

import javax.swing.*;
import java.awt.*;
import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.Comparator;
import java.util.List;

public class VentanaPrincipal extends JFrame {
    private SistemaCitas sistema;
    private DefaultListModel<String> modeloMedicos;
    private DefaultListModel<String> modeloPacientes;

    public VentanaPrincipal() {
        sistema = new SistemaCitas();
        modeloMedicos   = new DefaultListModel<>();
        modeloPacientes = new DefaultListModel<>();
        recargarListas();

        setTitle("Sistema Gestión Citas Médicas");
        setSize(800, 600);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JTabbedPane pestañas = new JTabbedPane();

// ----------- MÉDICO -----------
        JTabbedPane tabMedico = new JTabbedPane();
        tabMedico.addTab("Registrar", crearPanelRegistrarMedico());
        tabMedico.addTab("Mostrar", crearPanelMostrarCitasMedico());
        tabMedico.addTab("Disponibilidad", crearPanelConsultarDisponibilidad());
        tabMedico.addTab("Editar", crearPanelEditarMedico());
        pestañas.addTab("Médico", tabMedico);

// ----------- PACIENTE -----------
        JTabbedPane tabPaciente = new JTabbedPane();
        tabPaciente.addTab("Registrar", crearPanelRegistrarPaciente());
        tabPaciente.addTab("Editar", crearPanelEditarPaciente());
        tabPaciente.addTab("Historial / Citas", crearPanelMostrarCitasPaciente());
        pestañas.addTab("Paciente", tabPaciente);

// ----------- CITAS -----------
        pestañas.addTab("Asignar Citas", crearPanelAsignarCita());

// ----------- EN CONSULTA -----------
        pestañas.addTab("En Consulta", crearPanelEnConsulta());

        add(pestañas);
    }

    //aqui metodos
//Metodo EditarMedico

    private JPanel crearPanelEditarMedico() {
        JPanel panel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.anchor = GridBagConstraints.WEST;

        JLabel lId = new JLabel("ID Médico:");
        JTextField fId = new JTextField(10);

        JLabel lTel = new JLabel("Nuevo Teléfono:");
        JTextField fTel = new JTextField(15);

        JLabel lDir = new JLabel("Nueva Dirección:");
        JTextField fDir = new JTextField(20);

        JLabel lEsp = new JLabel("Nueva Especialidad:");
        String[] especialidades = {"Medicina General", "Pediatría", "Cardiología", "Ginecología", "Dermatología"};
        JComboBox<String> cbEsp = new JComboBox<>(especialidades);

        JLabel lHi = new JLabel("Nuevo Horario Inicio (HH:mm):");
        JTextField fHi = new JTextField(10);

        JLabel lHf = new JLabel("Nuevo Horario Fin (HH:mm):");
        JTextField fHf = new JTextField(10);

        JCheckBox chkAusente = new JCheckBox("Marcar como AUSENTE");
        JCheckBox chkActivo  = new JCheckBox("Marcar como ACTIVO");

        chkAusente.addActionListener(e -> {
            if (chkAusente.isSelected()) chkActivo.setSelected(false);
        });
        chkActivo.addActionListener(e -> {
            if (chkActivo.isSelected()) chkAusente.setSelected(false);
        });

        JButton bEditar = new JButton("Editar Médico");

        gbc.gridx = 0; gbc.gridy = 0; panel.add(lId, gbc);
        gbc.gridx = 1; panel.add(fId, gbc);
        gbc.gridx = 0; gbc.gridy = 1; panel.add(lTel, gbc);
        gbc.gridx = 1; panel.add(fTel, gbc);
        gbc.gridx = 0; gbc.gridy = 2; panel.add(lDir, gbc);
        gbc.gridx = 1; panel.add(fDir, gbc);
        gbc.gridx = 0; gbc.gridy = 3; panel.add(lEsp, gbc);
        gbc.gridx = 1; panel.add(cbEsp, gbc);
        gbc.gridx = 0; gbc.gridy = 4; panel.add(lHi, gbc);
        gbc.gridx = 1; panel.add(fHi, gbc);
        gbc.gridx = 0; gbc.gridy = 5; panel.add(lHf, gbc);
        gbc.gridx = 1; panel.add(fHf, gbc);
        gbc.gridx = 1; gbc.gridy = 6; panel.add(chkAusente, gbc);
        gbc.gridx = 1; gbc.gridy = 7; panel.add(chkActivo, gbc);
        gbc.gridx = 1; gbc.gridy = 8; gbc.anchor = GridBagConstraints.CENTER;
        panel.add(bEditar, gbc);

        bEditar.addActionListener(e -> {
            try {
                int id = Integer.parseInt(fId.getText().trim());
                Medico m = sistema.obtenerMedico(id);
                if (m == null) throw new IllegalArgumentException("Médico no encontrado");

                String tel = fTel.getText().trim();
                String dir = fDir.getText().trim();
                String esp = (String) cbEsp.getSelectedItem();
                String hi = fHi.getText().trim();
                String hf = fHf.getText().trim();

                LocalTime horaInicio = hi.isEmpty() ? m.getHorarioInicio() : LocalTime.parse(hi);
                LocalTime horaFin = hf.isEmpty() ? m.getHorarioFin() : LocalTime.parse(hf);
                if (horaFin.isBefore(horaInicio))
                    throw new IllegalArgumentException("El horario de fin no puede ser antes del inicio");

                boolean nuevoEstadoAusente = chkAusente.isSelected() ? true : chkActivo.isSelected() ? false : m.isAusente();

                sistema.actualizarDatosMedico(
                        id,
                        tel.isEmpty() ? m.getTelefono() : tel,
                        dir.isEmpty() ? m.getDireccion() : dir,
                        esp,
                        horaInicio,
                        horaFin,
                        nuevoEstadoAusente
                );

                JOptionPane.showMessageDialog(this,
                        "Médico actualizado correctamente",
                        "Éxito", JOptionPane.INFORMATION_MESSAGE);
                fId.setText(""); fTel.setText(""); fDir.setText("");
                fHi.setText(""); fHf.setText(""); chkAusente.setSelected(false);
                chkAusente.setSelected(false);
                chkActivo.setSelected(false);

                recargarListas();

            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this,
                        ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        return panel;
    }


    //Metodo EnConsulta

    private JPanel crearPanelEnConsulta() {
        JPanel panel = new JPanel(new BorderLayout());
        JPanel top = new JPanel(new GridLayout(4, 2, 10, 10));

        JLabel lIdPaciente = new JLabel("ID Paciente:");
        JTextField fIdPaciente = new JTextField();
        JLabel lNotas = new JLabel("Nota para agregar al historial:");
        JTextField fNotas = new JTextField();

        JButton bAgregarNota = new JButton("Agregar al Historial");
        JTextArea areaHistorial = new JTextArea();
        areaHistorial.setEditable(false);
        JScrollPane scroll = new JScrollPane(areaHistorial);

        top.add(lIdPaciente);
        top.add(fIdPaciente);
        top.add(lNotas);
        top.add(fNotas);
        top.add(new JLabel());
        top.add(bAgregarNota);

        panel.add(top, BorderLayout.NORTH);
        panel.add(scroll, BorderLayout.CENTER);

        bAgregarNota.addActionListener(e -> {
            try {
                int id = Integer.parseInt(fIdPaciente.getText().trim());
                String nota = fNotas.getText().trim();
                if (nota.isEmpty()) throw new IllegalArgumentException("La nota no puede estar vacía.");
                Paciente p = sistema.obtenerPaciente(id);
                if (p == null) throw new IllegalArgumentException("Paciente no encontrado.");
                p.agregarNotaHistoria(nota);
                areaHistorial.setText(p.getHistoriaMedica());
                fNotas.setText("");
                JOptionPane.showMessageDialog(this,
                        "Nota agregada al historial médico.",
                        "Éxito", JOptionPane.INFORMATION_MESSAGE);
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this,
                        ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        return panel;
    }

    private void recargarListas() {
        modeloMedicos.clear();
        for (Medico m : sistema.obtenerTodosMedicos()) {
            modeloMedicos.addElement(
                    m.getId() + ": " + m.getNombre()
                            + " – " + m.getEspecialidad()
                            + " (" + m.getHorarioInicio() + "–" + m.getHorarioFin() + ")"
                            + " – Estado: " + (m.isAusente() ? "AUSENTE" : "ACTIVO")
            );
        }

        modeloPacientes.clear();
        for (Paciente p : sistema.obtenerTodosPacientes()) {
            modeloPacientes.addElement(
                    p.getId() + ": " + p.getNombre()
            );
        }
    }

// metodo EditarPaciente
private JPanel crearPanelEditarPaciente() {
    JPanel panel = new JPanel(new GridBagLayout());
    GridBagConstraints gbc = new GridBagConstraints();

    JLabel lId = new JLabel("ID Paciente:");
    JTextField fId = new JTextField(10);
    JLabel lTel = new JLabel("Nuevo Teléfono:");
    JTextField fTel = new JTextField(15);
    JLabel lDir = new JLabel("Nueva Dirección:");
    JTextField fDir = new JTextField(20);

    JButton bEditar = new JButton("Editar Datos");

    gbc.insets = new Insets(5,5,5,5);
    gbc.anchor = GridBagConstraints.WEST;

    gbc.gridx = 0; gbc.gridy = 0; panel.add(lId, gbc);
    gbc.gridx = 1; panel.add(fId, gbc);

    gbc.gridx = 0; gbc.gridy = 1; panel.add(lTel, gbc);
    gbc.gridx = 1; panel.add(fTel, gbc);

    gbc.gridx = 0; gbc.gridy = 2; panel.add(lDir, gbc);
    gbc.gridx = 1; panel.add(fDir, gbc);

    gbc.gridx = 0; gbc.gridy = 3; panel.add(bEditar, gbc);

    bEditar.addActionListener(e -> {
        try {
            int id = Integer.parseInt(fId.getText().trim());
            String tel = fTel.getText().trim();
            String dir = fDir.getText().trim();

            sistema.editarPaciente(id, tel, dir);
            recargarListas();
            JOptionPane.showMessageDialog(this,
                    "Datos actualizados correctamente",
                    "Éxito", JOptionPane.INFORMATION_MESSAGE);
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this,
                    ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    });

    return panel;
}

    // crearPanelRegistrarMedico()

    private JPanel crearPanelRegistrarMedico() {
        JPanel panel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();

        JLabel lId = new JLabel("ID Médico:");
        JTextField fId = new JTextField(10);

        JLabel lNom = new JLabel("Nombre:");
        JTextField fNom = new JTextField(20);

        JLabel lCed = new JLabel("Cédula:");
        JTextField fCed = new JTextField(10);

        JLabel lEsp = new JLabel("Especialidad:");
        JComboBox<String> comboEsp = new JComboBox<>(new String[]{
                "Medicina General", "Pediatría", "Cardiología", "Ginecología", "Dermatología"
        });

        JLabel lHi = new JLabel("Horario Inicio (HH:mm):");
        JTextField fHi = new JTextField(10);

        JLabel lHf = new JLabel("Horario Fin (HH:mm):");
        JTextField fHf = new JTextField(10);

        JButton bReg = new JButton("Registrar Médico");

        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.anchor = GridBagConstraints.WEST;

        gbc.gridx = 0; gbc.gridy = 0; panel.add(lId, gbc);
        gbc.gridx = 1; panel.add(fId, gbc);

        gbc.gridx = 0; gbc.gridy = 1; panel.add(lNom, gbc);
        gbc.gridx = 1; panel.add(fNom, gbc);

        gbc.gridx = 0; gbc.gridy = 2; panel.add(lCed, gbc);
        gbc.gridx = 1; panel.add(fCed, gbc);

        gbc.gridx = 0; gbc.gridy = 3; panel.add(lEsp, gbc);
        gbc.gridx = 1; panel.add(comboEsp, gbc);

        gbc.gridx = 0; gbc.gridy = 4; panel.add(lHi, gbc);
        gbc.gridx = 1; panel.add(fHi, gbc);

        gbc.gridx = 0; gbc.gridy = 5; panel.add(lHf, gbc);
        gbc.gridx = 1; panel.add(fHf, gbc);

        gbc.gridx = 1; gbc.gridy = 6; gbc.anchor = GridBagConstraints.CENTER;
        panel.add(bReg, gbc);

        bReg.addActionListener(e -> {
            try {
                // ID
                String textoId = fId.getText().trim();
                if (!textoId.matches("\\d+")) {
                    throw new IllegalArgumentException("El ID debe contener solo números.");
                }
                int id = Integer.parseInt(textoId);
                if (sistema.obtenerMedico(id) != null) {
                    throw new IllegalArgumentException("Ya existe un médico con ese ID.");
                }

                // Nombre
                String nombre = fNom.getText().trim().replaceAll("\\s+", " ");
                if (!nombre.matches("(?i)[a-záéíóúñü.\\s]+")) {
                    throw new IllegalArgumentException("El nombre solo puede contener letras y espacios.");
                }

                // Cédula
                String cedula = fCed.getText().trim();
                if (!cedula.matches("\\d{10}")) {
                    throw new IllegalArgumentException("La cédula debe tener 10 dígitos numéricos.");
                }
                if (sistema.cedulaExiste(cedula)) {
                    throw new IllegalArgumentException("Ya existe un médico o paciente con esta cédula.");
                }

                // Horario
                LocalTime inicio = LocalTime.parse(fHi.getText().trim());
                LocalTime fin = LocalTime.parse(fHf.getText().trim());

                // Crear médico
                Medico m = new Medico(
                        id,
                        "Dr. " + nombre,
                        cedula,
                        "0000000000",
                        "Sin dirección",
                        (String) comboEsp.getSelectedItem(),
                        inicio,
                        fin
                );
                sistema.agregarMedico(m);
                recargarListas();

                JOptionPane.showMessageDialog(this,
                        "Médico registrado correctamente",
                        "Éxito", JOptionPane.INFORMATION_MESSAGE
                );

                // Limpiar campos
                fId.setText("");
                fNom.setText("");
                fCed.setText("");
                fHi.setText("");
                fHf.setText("");

            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this,
                        ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE
                );
            }
        });

        return panel;
    }

    // crearPanelRegistrarPaciente()
    private JPanel crearPanelRegistrarPaciente() {
        JPanel panel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();

        JLabel lId = new JLabel("ID Paciente:");
        JTextField fId = new JTextField(10);

        JLabel lNom = new JLabel("Nombre:");
        JTextField fNom = new JTextField(20);

        JLabel lCed = new JLabel("Cédula:");
        JTextField fCed = new JTextField(15);

        JLabel lTel = new JLabel("Teléfono:");
        JTextField fTel = new JTextField(15);

        JLabel lDir = new JLabel("Dirección:");
        JTextField fDir = new JTextField(20);

        JLabel lHist = new JLabel("Historial Médico:");
        JTextField fHist = new JTextField(30);

        JButton bReg = new JButton("Registrar Paciente");

        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.anchor = GridBagConstraints.WEST;

        gbc.gridx = 0; gbc.gridy = 0; panel.add(lId, gbc);
        gbc.gridx = 1;           panel.add(fId, gbc);

        gbc.gridx = 0; gbc.gridy = 1; panel.add(lNom, gbc);
        gbc.gridx = 1;           panel.add(fNom, gbc);

        gbc.gridx = 0; gbc.gridy = 2; panel.add(lCed, gbc);
        gbc.gridx = 1;           panel.add(fCed, gbc);

        gbc.gridx = 0; gbc.gridy = 3; panel.add(lTel, gbc);
        gbc.gridx = 1;           panel.add(fTel, gbc);

        gbc.gridx = 0; gbc.gridy = 4; panel.add(lDir, gbc);
        gbc.gridx = 1;           panel.add(fDir, gbc);

        gbc.gridx = 0; gbc.gridy = 5; panel.add(lHist, gbc);
        gbc.gridx = 1;           panel.add(fHist, gbc);

        gbc.gridx = 1; gbc.gridy = 6; gbc.anchor = GridBagConstraints.CENTER;
        panel.add(bReg, gbc);

        bReg.addActionListener(e -> {
            try {
                // Validación ID
                String textoId = fId.getText().trim();
                if (!textoId.matches("\\d+")) {
                    throw new IllegalArgumentException("El ID debe contener solo números positivos.");
                }
                int id = Integer.parseInt(textoId);
                if (sistema.obtenerPaciente(id) != null) {
                    throw new IllegalArgumentException("Ya existe un paciente con ese ID.");
                }

                // Validación nombre
                String nombre = fNom.getText().trim();
                if (!nombre.matches("[a-zA-ZáéíóúÁÉÍÓÚñÑ.\\s]+")) {
                    throw new IllegalArgumentException("El nombre solo puede contener letras y espacios.");
                }

                // Validación cédula (10 dígitos)
                String cedula = fCed.getText().trim();
                if (!cedula.matches("\\d{10}")) {
                    throw new IllegalArgumentException("La cédula debe contener exactamente 10 dígitos.");
                }

                // Validación teléfono
                String telefono = fTel.getText().trim();
                if (!telefono.matches("\\d+")) {
                    throw new IllegalArgumentException("El teléfono debe contener solo números.");
                }

                String direccion = fDir.getText().trim();
                String historial = fHist.getText().trim();

                Paciente p = new Paciente(id, nombre, cedula, telefono, direccion, historial);
                sistema.agregarPaciente(p);
                recargarListas();

                JOptionPane.showMessageDialog(this,
                        "Paciente registrado correctamente",
                        "Éxito", JOptionPane.INFORMATION_MESSAGE
                );

                // Limpiar campos
                fId.setText(""); fNom.setText("");
                fCed.setText(""); fTel.setText("");
                fDir.setText(""); fHist.setText("");

            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this,
                        ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE
                );
            }
        });

        return panel;
    }

    // crearPanelAsignarCita()
    private JPanel crearPanelAsignarCita() {
        JPanel panel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        JLabel lIdC = new JLabel("ID Cita:");
        JTextField fIdC = new JTextField(10);
        JLabel lIdM = new JLabel("ID Médico:");
        JTextField fIdM = new JTextField(10);
        JLabel lIdP = new JLabel("ID Paciente:");
        JTextField fIdP = new JTextField(10);
        JLabel lF   = new JLabel("Fecha (YYYY-MM-DD):");
        JTextField fF = new JTextField(10);
        JLabel lH   = new JLabel("Hora (HH:mm):");
        JTextField fH = new JTextField(10);
        JButton bAs = new JButton("Asignar Cita");

        gbc.insets = new Insets(5,5,5,5);
        gbc.anchor = GridBagConstraints.WEST;
        gbc.gridx=0; gbc.gridy=0; panel.add(lIdC, gbc);
        gbc.gridx=1;           panel.add(fIdC, gbc);
        gbc.gridx=0; gbc.gridy=1; panel.add(lIdM, gbc);
        gbc.gridx=1;           panel.add(fIdM, gbc);
        gbc.gridx=0; gbc.gridy=2; panel.add(lIdP, gbc);
        gbc.gridx=1;           panel.add(fIdP, gbc);
        gbc.gridx=0; gbc.gridy=3; panel.add(lF, gbc);
        gbc.gridx=1;           panel.add(fF, gbc);
        gbc.gridx=0; gbc.gridy=4; panel.add(lH, gbc);
        gbc.gridx=1;           panel.add(fH, gbc);
        gbc.gridx=1; gbc.gridy=5; gbc.anchor=GridBagConstraints.CENTER;
        panel.add(bAs, gbc);

        bAs.addActionListener(e -> {
            try {
                sistema.crearCita(
                        Integer.parseInt(fIdC.getText().trim()),
                        LocalDate.parse(fF.getText().trim()),
                        LocalTime.parse(fH.getText().trim()),
                        Integer.parseInt(fIdM.getText().trim()),
                        Integer.parseInt(fIdP.getText().trim())
                );
                JOptionPane.showMessageDialog(this,
                        "Cita asignada correctamente",
                        "Éxito", JOptionPane.INFORMATION_MESSAGE);
                fIdC.setText(""); fIdM.setText("");
                fIdP.setText(""); fF.setText(""); fH.setText("");
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this,
                        ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        return panel;
    }

    // crearPanelConsultarDisponibilidad()
    private JPanel crearPanelConsultarDisponibilidad() {
        JPanel panel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        JLabel lIdM = new JLabel("ID Médico:");
        JTextField fIdM = new JTextField(10);
        JLabel lF   = new JLabel("Fecha (YYYY-MM-DD):");
        JTextField fF = new JTextField(10);
        JLabel lH   = new JLabel("Hora (HH:mm):");
        JTextField fH = new JTextField(10);
        JButton bCon = new JButton("Consultar Disponibilidad");

        gbc.insets = new Insets(5,5,5,5);
        gbc.anchor = GridBagConstraints.WEST;
        gbc.gridx=0; gbc.gridy=0; panel.add(lIdM, gbc);
        gbc.gridx=1;           panel.add(fIdM, gbc);
        gbc.gridx=0; gbc.gridy=1; panel.add(lF, gbc);
        gbc.gridx=1;           panel.add(fF, gbc);
        gbc.gridx=0; gbc.gridy=2; panel.add(lH, gbc);
        gbc.gridx=1;           panel.add(fH, gbc);
        gbc.gridx=1; gbc.gridy=3; gbc.anchor=GridBagConstraints.CENTER;
        panel.add(bCon, gbc);

        bCon.addActionListener(e -> {
            try {
                Medico m = sistema.obtenerMedico(Integer.parseInt(fIdM.getText().trim()));
                if (m == null) throw new IllegalArgumentException("Médico no encontrado");
                LocalDate fe = LocalDate.parse(fF.getText().trim());
                LocalTime ho = LocalTime.parse(fH.getText().trim());
                if (ho.isAfter(LocalTime.of(12,0).minusSeconds(1)) && ho.isBefore(LocalTime.of(13,0))) {
                    JOptionPane.showMessageDialog(this,
                            "Médico en horario de almuerzo", "No disponible", JOptionPane.INFORMATION_MESSAGE);
                    return;
                }

                if (!m.estaDisponible(ho)) {
                    JOptionPane.showMessageDialog(this,
                            "Médico fuera de horario","No disponible",JOptionPane.INFORMATION_MESSAGE);
                    return;
                }

                boolean ocu = m.getCitas().stream()
                        .filter(c -> c.getFecha().equals(fe))
                        .anyMatch(c -> Math.abs(Duration.between(c.getHora(), ho).toMinutes()) < 60);
                JOptionPane.showMessageDialog(this,
                        ocu ? "Cita cercana. NO disponible" : "Disponible",
                        ocu ? "No disponible" : "Disponible", JOptionPane.INFORMATION_MESSAGE);
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this,
                        ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        return panel;
    }

    // crearPanelMostrarCitasMedico()
    private JPanel crearPanelMostrarCitasMedico() {
        JPanel panel = new JPanel(new BorderLayout());
        JPanel north = new JPanel();

        north.add(new JLabel("ID Médico:"));
        JTextField fId = new JTextField(10);
        north.add(fId);
        JButton bMos = new JButton("Mostrar Citas");
        north.add(bMos);
        panel.add(north, BorderLayout.NORTH);

        JTextArea area = new JTextArea();
        area.setEditable(false);
        panel.add(new JScrollPane(area), BorderLayout.CENTER);

        bMos.addActionListener(e -> {
            try {
                int id = Integer.parseInt(fId.getText().trim());
                Medico m = sistema.obtenerMedico(id);
                if (m == null) {
                    area.setText("Médico no encontrado.");
                    return;
                }

                StringBuilder sb = new StringBuilder();
                sb.append("Médico: ").append(m.getNombre())
                        .append(" – Cédula: ").append(m.getCedula()).append("\n")
                        .append("Especialidad: ").append(m.getEspecialidad()).append("\n")
                        .append("Horario: ").append(m.getHorarioInicio())
                        .append("–").append(m.getHorarioFin()).append("\n")
                        .append("Estado: ").append(m.isAusente() ? "INACTIVO (Ausente)" : "ACTIVO (Presente)").append("\n\n");

                List<Cita> lista = m.getCitas();
                if (lista.isEmpty()) {
                    sb.append("No hay citas registradas para este médico.");
                } else {
                    for (Cita c : lista) {
                        String estadoCita = m.isAusente() ? "CANCELADA (Médico ausente)" : "ACTIVA";
                        sb.append(String.format(
                                "Cita %d: %s %s – Paciente: %s – Estado: %s\n",
                                c.getIdCita(), c.getFecha(), c.getHora(),
                                c.getPaciente().getNombre(),
                                estadoCita
                        ));
                    }
                }

                area.setText(sb.toString());

            } catch (NumberFormatException ex) {
                area.setText("El ID debe ser un número válido.");
            }
        });

        JList<String> listaMed = new JList<>(modeloMedicos);
        JScrollPane scrollMed = new JScrollPane(listaMed);
        scrollMed.setBorder(BorderFactory.createTitledBorder("Médicos Registrados"));
        panel.add(scrollMed, BorderLayout.SOUTH);

        return panel;
    }


    // crearPanelMostrarCitasPaciente()
    private JPanel crearPanelMostrarCitasPaciente() {
        JPanel panel = new JPanel(new BorderLayout());
        JPanel north = new JPanel();
        north.add(new JLabel("ID Paciente:"));
        JTextField fId = new JTextField(10);
        north.add(fId);
        JButton bMos = new JButton("Mostrar Citas");
        north.add(bMos);
        panel.add(north, BorderLayout.NORTH);

        JTextArea area = new JTextArea();
        area.setEditable(false);
        panel.add(new JScrollPane(area), BorderLayout.CENTER);

        bMos.addActionListener(e -> {
            try {
                int id = Integer.parseInt(fId.getText().trim());
                Paciente p = sistema.obtenerPaciente(id);
                if (p == null) {
                    area.setText("Paciente no encontrado.");
                    return;
                }

                StringBuilder sb = new StringBuilder();
                sb.append("Paciente: ").append(p.getNombre())
                        .append(" – Cédula: ").append(p.getCedula()).append("\n")
                        .append("Historia Clínica:\n").append(p.getHistoriaMedica())
                        .append("\n\n");

                List<Cita> lista = p.getCitas();
                lista.sort(Comparator.comparing(Cita::getFecha).thenComparing(Cita::getHora));
                if (lista.isEmpty()) sb.append("No hay citas.");
                else for (Cita c : lista) {
                    String estado = c.getMedico().isAusente() ? "CANCELADA" : "ACTIVA";
                    sb.append(String.format(
                            "Cita %d: %s %s – Médico: %s – Estado: %s\n",
                            c.getIdCita(),
                            c.getFecha(),
                            c.getHora(),
                            c.getMedico().getNombre(),
                            estado
                    ));
                }

                area.setText(sb.toString());

            } catch (NumberFormatException ex) {
                area.setText("ID debe ser un número entero.");
            }
        });

        JList<String> listaPac = new JList<>(modeloPacientes);
        JScrollPane scrollPac = new JScrollPane(listaPac);
        scrollPac.setBorder(BorderFactory.createTitledBorder("Pacientes Registrados"));
        panel.add(scrollPac, BorderLayout.SOUTH);

        return panel;
    }


    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new VentanaPrincipal().setVisible(true));
    }
}
